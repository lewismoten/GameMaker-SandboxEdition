@ECHO OFF
TEDDY config
