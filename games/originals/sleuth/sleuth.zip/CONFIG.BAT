@ECHO OFF
FINAL config
