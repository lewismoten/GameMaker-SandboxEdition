@ECHO OFF
CARL config
