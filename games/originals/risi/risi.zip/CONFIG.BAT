@ECHO OFF
RISI config
