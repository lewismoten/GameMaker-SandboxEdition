@ECHO OFF
BAKERS config
