@ECHO OFF
TUNEUP config
