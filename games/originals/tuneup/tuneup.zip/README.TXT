TUNE-UP
Version 2.3 - November 1994
A Sandbox Software game, made with Game-Maker 3.0.

It's the morning of the Clown Club parade, and THE CHEZ won't run
right: Gwinn tipped the instrument trunk into the car. With no
wrenches, Doc Leo shrinks down and tunes it up by ear, with Sir
Reginald III, his rubber chicken, doing the fiddly bits.

To play, run TUNEUP.EXE (or PLAYGAME TUNEUP.GAM).
A Sound Blaster plays the music and the notes; the PC speaker plays
the notes without one.

Free to share: see LICENSE.TXT.
