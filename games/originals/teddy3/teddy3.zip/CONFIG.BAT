@ECHO OFF
TEDDY3 config
