@ECHO OFF
PASS config
