The Mountain Moved Next Door
============================

A Game-Maker 3.00 game for DOS. MOUNTAIN.EXE is Game-Maker's stand-alone player;
it plays MOUNTAIN.GAM and the other files in this folder.

On a DOS PC, read INSTALL.TXT for hard-disk installation, manual copying,
floppy disks and sound setup. Run INSTALL from the source directory.

Play it in DOSBox (https://www.dosbox.com)
  1. Unzip this folder somewhere, for example C:\GAMES\MOUNTAIN or ~/games/MOUNTAIN.
  2. Start DOSBox and type:
       mount c <the folder you unzipped into>
       c:
       MOUNTAIN
  3. The first time, a setup screen asks about your sound card and VGA card.
     For DOSBox choose "Sound Blaster", port 220, interrupt 7, and leave the
     VGA chip on "Auto-Detect". Run CONFIG to change these later.

Keys
  F1 the game's instructions, F2 status, F3 music on/off, F4 sound on/off,
  F5 save, F6 load, Esc leaves a level. The game's own keys are in its
  instructions.

Made with Game-Maker by Recreational Software Designs, exported by Game-Maker: Sandbox Edition
(a modified fork of RSD Game-Maker 3.0: https://github.com/lewismoten/GameMaker-SandboxEdition).

Notices
  MOUNTAIN.EXE is Game-Maker 3.00's XFERPLAY.EXE as it came on the Game-Maker CD, and
  CONFIG.HLP its setup screen's help text, from the same CD.
  Game-Maker's source code was released under the MIT License:

  Copyright (c) 2014 gandrewstone

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.

  MOUNTAIN.EXE also holds Borland C++'s run-time library (Copyright 1991 Borland
  Intl.) and Creative's Sound Blaster FM music functions (Copyright (c) Creative
  Technology Pte Ltd, 1990), which it was built with. SNDBLAST.DRV is Creative's
  Sound Blaster voice driver (Copyright (c) Creative Technology Pte Ltd.,
  1989-1990. All rights reserved), included as Game-Maker's Transfer utility
  included it with every game. These parts are their owners' and are not
  covered by the MIT License. Sound Blaster is a trademark of Creative
  Technology Ltd.
