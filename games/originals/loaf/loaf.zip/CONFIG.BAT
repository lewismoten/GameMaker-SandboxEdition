@ECHO OFF
LOAF config
