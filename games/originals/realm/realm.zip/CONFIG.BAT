@ECHO OFF
TUIT config
