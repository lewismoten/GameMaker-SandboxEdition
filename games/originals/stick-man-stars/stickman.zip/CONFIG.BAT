@ECHO OFF
STARS config
