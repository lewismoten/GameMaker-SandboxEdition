@ECHO OFF
RECKON config
