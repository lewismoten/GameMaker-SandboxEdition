@ECHO OFF
REM Run from the source disk directory, not by a path from another drive.
IF NOT "%2"=="" GOTO usage
IF "%1"=="" GOTO default
IF "%1"=="C:" GOTO drive
IF "%1"=="c:" GOTO drive
IF "%1"=="D:" GOTO drive
IF "%1"=="d:" GOTO drive
IF "%1"=="E:" GOTO drive
IF "%1"=="e:" GOTO drive
IF "%1"=="F:" GOTO drive
IF "%1"=="f:" GOTO drive
IF "%1"=="G:" GOTO drive
IF "%1"=="g:" GOTO drive
IF "%1"=="H:" GOTO drive
IF "%1"=="h:" GOTO drive
IF "%1"=="I:" GOTO drive
IF "%1"=="i:" GOTO drive
IF "%1"=="J:" GOTO drive
IF "%1"=="j:" GOTO drive
IF "%1"=="K:" GOTO drive
IF "%1"=="k:" GOTO drive
IF "%1"=="L:" GOTO drive
IF "%1"=="l:" GOTO drive
IF "%1"=="M:" GOTO drive
IF "%1"=="m:" GOTO drive
IF "%1"=="N:" GOTO drive
IF "%1"=="n:" GOTO drive
IF "%1"=="O:" GOTO drive
IF "%1"=="o:" GOTO drive
IF "%1"=="P:" GOTO drive
IF "%1"=="p:" GOTO drive
IF "%1"=="Q:" GOTO drive
IF "%1"=="q:" GOTO drive
IF "%1"=="R:" GOTO drive
IF "%1"=="r:" GOTO drive
IF "%1"=="S:" GOTO drive
IF "%1"=="s:" GOTO drive
IF "%1"=="T:" GOTO drive
IF "%1"=="t:" GOTO drive
IF "%1"=="U:" GOTO drive
IF "%1"=="u:" GOTO drive
IF "%1"=="V:" GOTO drive
IF "%1"=="v:" GOTO drive
IF "%1"=="W:" GOTO drive
IF "%1"=="w:" GOTO drive
IF "%1"=="X:" GOTO drive
IF "%1"=="x:" GOTO drive
IF "%1"=="Y:" GOTO drive
IF "%1"=="y:" GOTO drive
IF "%1"=="Z:" GOTO drive
IF "%1"=="z:" GOTO drive
GOTO usage
:drive
SET GMIDRV=%1
IF NOT "%GMIDRV%"=="%1" GOTO failed
GOTO begin
:default
SET GMIDRV=C:
IF NOT "%GMIDRV%"=="C:" GOTO failed
:begin
ECHO Copy the game to %GMIDRV%\NEEDLE.
ECHO Existing files with the same names will be overwritten. Back up saves first.
ECHO Press Ctrl+C and answer Y to cancel, or press any other key to continue.
PAUSE
IF NOT EXIST %GMIDRV%\NUL GOTO failed
IF EXIST %GMIDRV%\NEEDLE\NUL GOTO ready
MD %GMIDRV%\NEEDLE
:ready
IF NOT EXIST %GMIDRV%\NEEDLE\NUL GOTO failed
:disk1
:copy1
COPY /B *.* %GMIDRV%\NEEDLE /V
FOR %%F IN (*.*) DO IF NOT EXIST %GMIDRV%\NEEDLE\%%F GOTO failed
ECHO Check the COPY messages above. If ANY error appeared, STOP here.
ECHO Press Ctrl+C and answer Y; fix the problem before trying again.
ECHO Only if there were NO errors, press any other key to continue.
PAUSE
ECHO Copy passes ended. This is not an automatic check of file contents.
ECHO If every disk copied without errors, run these commands:
ECHO   %GMIDRV%
ECHO   CD \NEEDLE
ECHO   CONFIG
ECHO   NEEDLE.EXE
ECHO Run CONFIG once for sound and video, then run the game.
ECHO Read INSTALL.TXT for manual copying and sound setup.
GOTO end
:failed
ECHO INSTALL STOPPED: environment, drive, directory or copied file problem.
ECHO Check free space, write protection and the source disk. Read INSTALL.TXT.
ECHO Files already copied have NOT been removed. Installation may be incomplete.
GOTO end
:usage
ECHO Usage: INSTALL [drive]   Example: INSTALL D:   Default: C:
ECHO Use a hard disk drive letter C: through Z:, not a directory or path.
:end
SET GMIDRV=
