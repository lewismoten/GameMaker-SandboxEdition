@ECHO OFF
PARADE config
