@ECHO OFF
DEPTH config
