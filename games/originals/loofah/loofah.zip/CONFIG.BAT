@ECHO OFF
LOOFAH config
