@ECHO OFF
SWEATS config
