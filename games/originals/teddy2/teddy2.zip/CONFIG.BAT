@ECHO OFF
TEDDY2 config
