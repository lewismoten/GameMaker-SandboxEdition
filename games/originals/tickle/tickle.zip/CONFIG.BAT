@ECHO OFF
TICKLE config
