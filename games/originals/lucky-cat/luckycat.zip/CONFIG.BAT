@ECHO OFF
LUCKY config
