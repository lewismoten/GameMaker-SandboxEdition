@ECHO OFF
NOODLE config
